const ostan = require('./ostan.json');
const shahr = require('./shahr.json');

module.exports = {
  ostan,
  shahr
};